require(Pmetrics)
wd <- commandArgs()[6]
setwd(wd)
ERRreport(wd,icen=NULL,type="ERR")


