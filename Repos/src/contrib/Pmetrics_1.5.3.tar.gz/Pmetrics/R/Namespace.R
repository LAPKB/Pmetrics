#' @useDynLib Pmetrics knn
#' @exportPattern "^[^\\.]"

fun <- function() {}
