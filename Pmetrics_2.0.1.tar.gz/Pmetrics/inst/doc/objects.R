## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo = F, message = F---------------------------------------------
library(Pmetrics)

## ----echo = F, results = 'asis'-----------------------------------------------
library(knitr)
tabObj <- read.csv("Data/ObjectsR6.csv",na.strings=".")
kable(tabObj)

## ----echo=T, eval = F---------------------------------------------------------
#  res1 <- PM_load(1)
#  res1$op
#  res1$op$time
#  res1$op$data #this accesses the whole observed vs. predicted data frame

## ----echo = T, eval = F-------------------------------------------------------
#  res1 <- PM_load(1)
#  res1$op
#  res1$op$summary()
#  res1$op$plot()

## ----echo = F, results = 'asis'-----------------------------------------------
library(knitr)
tabObj <- read.csv("Data/ObjectsLegacy.csv",na.strings=".")
kable(tabObj)

## ----echo = T, eval = F-------------------------------------------------------
#  PMload(1)
#  op.1
#  final.1
#  cycle.1
#  cov.1
#  post.1 #NPAG only
#  pop.1 #NPAG only
#  #other results could be included if PMsave() had been run previously

## ----echo=F, eval = F---------------------------------------------------------
#  PMload(1)
#  summary(op.1)
#  plot(op.1)
#  #op.1$plot() will not work since op.1 is not an R6 object and has no attached methods

