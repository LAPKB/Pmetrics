## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=F, message=F-------------------------------------------------
library(Pmetrics)

## ----echo=T, eval=F-----------------------------------------------------------
#  PMtree("DrugX")

## ----echo=T, eval=F-----------------------------------------------------------
#  library(Pmetrics)
#  PM_tutorial()

## ----echo=T, eval=F-----------------------------------------------------------
#  
#  #Example 1 - data and model objects
#  dat <- PM_data$new("data.csv")
#  mod1 <- PM_model$new(list(...))
#  fit1 <- PM_fit$new(dat, mod1)
#  
#  #Example 2 - data file and PM_model object
#  fit2 <- PM_fit$new(data = "data.csv", model = mod1)
#  
#  #Example 3 - data object and model file
#  PMdata <- PMreadMatrix("data.csv")
#  fit3 <- PM_fit$new(data = PMdata, model = "model.txt")
#  

## ----echo=T, eval=F-----------------------------------------------------------
#  fit1$check() #This will check the consistency between the model and the data
#  
#  fit2$save("fit2.rds") #This will save the fit to a file in your working directory
#  
#  fit2_again <- PM_fit$load("fit2.rds") #This will load the fit again from disk

## ----echo=T, eval=F-----------------------------------------------------------
#  #default run parameters
#  fit3$run()
#  
#  #change the cycle number from default 100
#  fit3$run(cycles=500)
#  
#  #change the engine from default NPAG
#  fit3$run(engine = "IT2B")

## ----echo=T, eval=F-----------------------------------------------------------
#  
#  library(Pmetrics)
#  #Run 1 - add your run description here
#  setwd("working directory")
#  NPrun() #for NPAG or ITrun() for IT2B

## ----echo=T, eval=F-----------------------------------------------------------
#  #Using default names data.csv and model.txt
#  NPrun()
#  
#  #Using custom names
#  ITrun(model = "model1.txt", data = "mydata.csv")
#  
#  #Grab data from run 1 and use default model.txt
#  NPrun(data=1)
#  
#  #Use model and data from run 2 and continue where run 2 ended
#  NPrun(data=2, model=2, prior=2, cycles=1000)

## ----echo=T, eval=F-----------------------------------------------------------
#  my_run <- PM_load(1)

## ----echo=T, eval=F-----------------------------------------------------------
#  exRes <- PM_load(1)
#  exRes$final$plot() #see ?plot.PM_final
#  exRes$op$plot(type="pop") #see ?plot.PM_op,
#  exRes$data$plot(overlay = F,
#                  line = list(pred = list(exRes$post, color = "green"), join = F),
#                  marker = list(symbol = "diamond-open", color = "blue"),
#                  log = T) # see ?plot.PM_data

## ----echo=T, eval=F-----------------------------------------------------------
#  plot(final.1)
#  plot(cycle.1)
#  plot(op.1,type="pop") #or plot(op.1$pop1)
#  plot(op.1) #default is to plot posterior predictions for output 1
#  plot(op.1,type="pop",resid=T)

## ----echo=T, eval=F-----------------------------------------------------------
#  library(Pmetrics)
#  #Run 1 - Ka, Kel, V, all subjects
#  setwd("working directory")
#  NPrun() #assumes model="model.txt" and data="data.csv"
#  PMload(1)

