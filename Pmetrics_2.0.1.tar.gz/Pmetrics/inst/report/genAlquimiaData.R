require(Pmetrics)
wd <- commandArgs()[6]
setwd(wd)
GenAlData(wd)
