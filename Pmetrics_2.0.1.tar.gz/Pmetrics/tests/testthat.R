library(testthat)
library(Pmetrics)

test_check("Pmetrics")
