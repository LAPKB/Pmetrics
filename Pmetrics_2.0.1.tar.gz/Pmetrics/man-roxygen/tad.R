#' Boolean operator to use time after dose rather than time after start.  Default is `FALSE`.
