#' A vector of subject IDs to include in the plot, e.g. c(1:3,5,15)
