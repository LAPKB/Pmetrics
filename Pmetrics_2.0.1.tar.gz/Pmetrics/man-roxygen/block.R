#' Which block to plot, where blocks are defined
#' by dose reset events (EVID = 4) in the data. Default is 1.
