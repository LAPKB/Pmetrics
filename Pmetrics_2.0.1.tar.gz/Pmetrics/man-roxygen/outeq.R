#' Which output equation to plot. Default is 1.
