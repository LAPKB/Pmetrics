#' Multiplication factor for y axis, e.g. to convert mg/L to ng/mL
