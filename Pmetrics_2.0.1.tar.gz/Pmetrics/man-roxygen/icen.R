#' Can be either "median" for the predictions based on medians of`pred.type` 
#' parameter value distributions, or "mean".  Default is "median".
