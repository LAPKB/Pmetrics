#' A vector of subject IDs to exclude in the plot, e.g. c(4,6:14,16:20)
