#' Individual Bayesian population prior predictions at short intervals
#'
#' Returns the Bayesian population prior predictions at short intervals specified during the NPAG run,
#' up to 12 minutes.
#'
#' @param data An \emph{NPAG} object created by \code{\link{NPparse}}
#' @param icen Either \dQuote{mean}, \dQuote{median}, or \dQuote{mode} (the latter for NPAG only), to specifiy the
#' summary of the individual Bayesian Posterior joint density function for each parameter.  The default is \dQuote{median}.
#' @return A dataframe of class \emph{PMpop} with columns \dQuote{id}, \dQuote{time}, \dQuote{pred1}...\dQuote{predx},
#' where \emph{x} is the number of output equations.
#' @author Michael Neely

makePop <- function (data,icen="median") {
  require(utils)
  #get data
  if(!inherits(data,"NPAG")) stop(paste("Use NPparse() to generate an NPAG data object.\n"))
  #set pop summary
  icen <- switch(icen,mean=1,median=2,mode=3,2) #default is median
  
  #number of subjects
  nsub <- data$nsub
  #number of output equations
  nout <- data$numeqt
  #number of prediction points per subject
  npred <- data$numt
  
  
  pop <- data.frame(id=rep(data$sdata$id,each=max(npred)))
  pop$time <- c(t(data$ttpred))
  popPred <- list()
  for(i in 1:nout){
    popPred[[i]] <- c(t(data$ypredpopt[1:nsub,i,,icen]))
    pop <- cbind(pop,popPred[[i]])
  }
  names(pop)<-c("id","time",paste("pred",1:nout,sep=""))
  pop <- pop[!is.na(pop$time),]
  pop$id <- factor(as.character(pop$id),levels=unique(as.character(pop$id)))
  pop$time <- unlist(tapply(pop$time,pop$id,function(x) x-x[1]))
  blocks <- tapply(pop$time,pop$id,function(x) sum(x==0))
  blocks2 <- unlist(mapply(function(x) 1:x,blocks))
  time0 <- c(which(pop$time==0),nrow(pop))
  blocks3 <- rep(blocks2,times=diff(time0))
  pop$block <- c(blocks3,tail(blocks3,1))
  
  class(pop) <- c("PMpop","data.frame")
 
  return(pop)

}

