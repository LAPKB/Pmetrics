#' Perform a stepwise linear regression on all covariates and Bayesian posterior parameters
#'
#' This function will perform stepwise linear regressions on a PMcov object loaded by \code{\link{NPload}} or \code{\link{ITload}},
#' or made by \code{\link{makeCov}}.  Every covariate in the model will be tested in a stepwise linear regression for their relationships
#' to each parameter in the model.  Bayesian posterior parameters and individual covariates are used.
#'
#' @title Stepwise covariate-parameter regressions
#' @param object A PMcov object loaded by \code{\link{PMload}}
#' or made by \code{\link{makeCov}}.
#' @param icen A character vector to summarize covariate values.  Default is \dQuote{mean}, but can also be either
#' \dQuote{median}, or \dQuote{mode}.  
#' @param direction The direction for covariate elmination can be \dQuote{backward}, \dQuote{forward}, or \dQuote{both}.  
#' \emph{both} is the default.
#' @return A matrix with covariates in the rows and parameters in the columns.  Values for the matrix are the multi-variate P-values.
#' A value of \code{NA} indicates that the variable was not retained in the final model.
#' @author Michael Neely
#' @seealso \code{\link{step}}

PMstep <- function(object,icen="mean",direction="both"){
  if(!inherits(object,"PMcov")) stop("Please supply a PMcov object made by makeCov or loaded with NPload or ITload.\n")
  ncov <- attr(object,"ncov")
  if(is.null(ncov)){
    ncov <- as.numeric(readline("Your covariate object is from a previous version of Pmetrics.  Enter the number of covariates: "))
  }
  if(ncov==0) stop("\nThere are no covariates in the data.\n")
  nvar <- ncol(object)-ncov-2
  
  #summarize cov object by icen
  choice <- function(x,icen){
    switch(icen,mean=mean(x),median=median(x),mode=as.numeric(names(sort(-table(x)))[1]),median(x))
  }
  temp3 <- NA
  for (i in unique(object$id)){
    temp <- object[object$id==i,]
    if(nrow(temp)>1){
      temp2 <- apply(temp,2,choice,icen=icen)
    } else temp2 <- temp
    temp3 <- rbind(temp3,temp2)
  }
  object <- data.frame(temp3[-1,],row.names=1:(nrow(temp3)-1))
  object <- object[,-2] #take out time column
  
  cov.cross <- data.frame(matrix(NA,ncol=nvar,nrow=ncov,dimnames=list(names(object)[2:(ncov+1)],names(object)[(ncov+2):ncol(object)])))
  
  for(i in 1:ncol(cov.cross)){
    temp <- cbind(object[,(ncov+1+i)],object[,2:(ncov+1)])
    names(temp)[1] <- names(object)[ncov+1+i]
    fo <- as.formula(paste(names(temp)[1]," ~ ",paste(names(temp)[-1],collapse=" + "),sep=""))
    lm.temp <- eval(substitute(lm(fo, temp)))
    step.temp <- step(lm.temp,direction=direction,trace=0)
    p.val <- summary(step.temp)$coefficients[,4]
    cov.cross[,i] <- sapply(row.names(cov.cross),function(x) p.val[match(x,names(p.val))])    
  }  
  return(cov.cross)
}
