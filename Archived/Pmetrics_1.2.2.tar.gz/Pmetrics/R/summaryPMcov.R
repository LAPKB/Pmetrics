#' Summarize a Pmetrics Covariate object
#'
#' Summarize covariates and Bayesian posterior parameter values for each subject.
#'
#' @title Summarize Covariates and Bayesian Posterior Parameter Values
#' @method summary PMcov
#' @param x A PMop object made by \code{\link{makeOP}}.
#' @param FUN Default is median, but can specify mean, sd, or other function matched by \code{\link{match.fun}}.
#' @return A data frame with the summary of the PMcov object for each subject's covariates and 
#' Bayesian posterior parameter values.
#' @author Michael Neely
#' @seealso \code{\link{makeCov}}
#' @export

summary.PMcov <- function(x,FUN="median"){
  sumCov <- aggregate(x,list(x$id),match.fun(FUN),na.rm=T)
  #remove the first grouping column
  sumCov <- sumCov[,-1]
  return(sumCov)
}

