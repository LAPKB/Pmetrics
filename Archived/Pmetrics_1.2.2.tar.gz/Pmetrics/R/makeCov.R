#' Generates an data.frame with subject-specific covariate data from an \emph{NPAG} or \emph{IT2B} object
#'
#' For each subject, \code{makeCov} extracts covariate information and Bayesian posterior parameter estimates.
#' This output of this function is suitable for exploration of covariate-parameter, covariate-time, or parameter-time relationships.
#'
#' @title Extract covariate data
#' @param data A suitable data object of the \emph{NPAG} or \emph{IT2B} class (see \code{\link{NPparse}} or \code{\link{ITparse}}).
#' @param icen Either \dQuote{mean}, \dQuote{median}, or \dQuote{mode} (the latter for NPAG only), to specifiy the
#' summary of the individual Bayesian Posterior joint density function for each parameter.  The default is \dQuote{median}.
#' @return The output of \code{makeCov} is a dataframe of class \emph{PMcov},
#' which has \emph{nsub} rows and the following columns:
#' \item{id }{Subject identification}
#' \item{time }{Times of covariate observations}
#' \item{covnames... }{Columns with each covariate observations in the dataset for each subject and \code{time} }
#' \item{parnames... }{Columns with each parameter in the model and the \code{icen} summary
#' for each subject, replicated as necessary for covariate observation times }
#' A plot method exists in \code{\link{plot}} for \emph{makeCov} objects.
#' @author Michael Neely
#' @seealso \code{\link{NPparse}}, \code{\link{ITparse}}, \code{\link{plot.PMcov}}
#' @examples
#' data(PMex1)
#' cov <- makeCov(PMex1)
#' cov
#' names(cov)

makeCov <- function(data,icen="median"){
  if(!inherits(data,"NPAG") & !inherits(data,"IT2B")) stop(paste("Use NPparse() or ITparse() to generate an Pmetrics NPAG or IT2B object.\n"))
  ncov <- data$ncov
  nvar <- data$nvar
  nsub <- data$nsub
  if(ncov>0){
    cov <- data$dosecov[,c(2,5:(ncov+4))]
  } else {
    cov <- data$dosecov[,2]
  }
  cov <- data.frame(cov)  
  cov <- cbind(data$sdata$id[data$dosecov[,1]],cov)
  if(inherits(data,"NPAG")){par <- matrix(as.numeric(switch(icen,mean=data$bmean,median=t(data$baddl[6,,]),mode=data$baddl[,,1],t(data$baddl[6,,]))),ncol=nvar)}
  if(inherits(data,"IT2B")){par <- matrix(as.numeric(switch(icen,mean=data$parbay[,,1],median=data$parbay[,,2],data$parbay[,,2])),ncol=nvar)}
  par.exp <- par[rep(1:nsub,table(data$dosecov[,1])),]
  cov <- cbind(cov,par.exp)

  if (ncov>0) {
    names(cov) <- c("id","time",tolower(data$covnames),data$par)
  } else {
    names(cov) <- c("id","time",data$par)
    
  }
  class(cov) <- c("PMcov","data.frame")
  attr(cov,"ncov") <- ncov
  return(cov)
}


