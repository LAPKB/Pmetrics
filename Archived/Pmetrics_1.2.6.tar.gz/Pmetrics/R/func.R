func= function( x, a) {
 return(   sin(pi*x) - (1-a)*pi*x)
}
