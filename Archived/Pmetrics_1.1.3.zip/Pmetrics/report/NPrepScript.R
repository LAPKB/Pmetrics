require(Pmetrics)
wd <- commandArgs()[6]
setwd(wd)
NPreport(wd)



