require(Pmetrics)
wd <- commandArgs()[6]
setwd(wd)
PMreport(wd,type="IT2B")


