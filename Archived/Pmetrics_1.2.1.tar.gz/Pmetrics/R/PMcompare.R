#' Compare NPAG or IT2B runs
#' 
#' Objects can be specified separated by commas, e.g. PMcompare(NPdata.1,NPdata.2,NPdata.3) followed by
#' any arguments you wish to \code{\link{plot.PMop}}, \code{\link{mtsknn.eq}}. P-values are based on comparison using the nearest neighbors
#' approach in the MTSKNN package if all models are non-parametrics.  Models may only be compared on parameters that are included
#' in the first model.  The P-value is the comparison between each model and the first model in
#' the list.  Missing P-values are when a model has no parameter names in common with the first
#' model, and for the first model compared to itself, or when models from IT2B runs are included.  Significant P-values indicate that the null
#' hypothesis should be rejected, i.e. the joint distributions between the two compared models are 
#' significantly different.
#'
#' @title Compare NPAG or IT2B runs
#' @param x The first NPAG or IT2B object obtained after a run with \code{\link{PMload}},
#' e.g. NPdata.1.  This will serve as the reference output for P-value testing (see details).
#' @param y The second NPAG or IT2B object.
#' @param \dots Additional NPAG or IT2B objects to compare.  See details.  Also, parameters to be passed to \code{\link{plot.PMop}} 
#' if \code{plot} is true as well as to \code{\link{mtsknn.eq}}.  Order does not matter.
#' @param outeq Number of the output equation to compare; default is 1
#' @param plot Boolean operator selecting whether to generate observed vs. predicted plots for each data object
#' as in \code{\link{plot.PMop}}
#' @param resid Boolean operator selecting whether to generate residual plots for each data object
#' as in \code{\link{plot.PMop}}, ignored if \code{plot} is false.
#' @return A data frame with the following objects for each model to analyze:
#'  \item{name }{The name of the data}
#'  \item{type }{NPAG or IT2B data}
#'  \item{nsub }{Number of subjects in the model}
#'  \item{nvar }{Number of random parameters in the model}
#'  \item{par }{Names of random parameters}
#'  \item{cycles }{Number of cycles run}
#'  \item{converge }{Boolean value if convergence occurred.}
#'  \item{ll }{Final cycle -2*Log-likelihood }
#'  \item{aic }{Final cycle Akaike Information Criterion}
#'  \item{bic }{Final cycle Bayesian (Schwartz) Information Criterion }
#'  \item{popBias }{Bias, or mean weighted prediction error of predictions based on population parameters minus observations}
#'  \item{popImp }{Imprecision, or bias-adjusted mean weighted squared error of predictions based on population parameters minus observations }
#'  \item{popPerRMSE}{Percent root mean squared error of predictions based on population parameters minus observations}
#'  \item{postBias }{Bias, or mean weighted prediction error of predictions - observations  based on posterior parameters}
#'  \item{postImp }{Imprecision, or bias-adjusted mean weighted squared error of predictions - observations based on posterior parameters}
#'  \item{postPerRMSE}{Percent root mean squared error of predictions based on posterior parameters minus observations}
#'  \item{pval }{P-value for each model compared to the first. See details.}
#' @author Michael Neely
#' @seealso \code{\link{PMload}}, \code{\link{plot.PMop}}, \code{\link{mtsknn.eq}}
#' @examples
#' data(PMex1) #NPAG results
#' data(PMex2) #IT2B results
#' PMcompare(NPdata.1,ITdata.1) #doesn't make much sense but gives the idea

PMcompare <- function (x,y,...,outeq=1,plot=F){
  if(missing(x) | missing(y)) stop("You must specify at least two NPdata and/or ITdata objects for PMcompare.\n")
  if(!inherits(x,c("NPAG","IT2B"))) stop("You no longer need to specify objects as a list object.  See help.\n")
  #parse dots
  if(length(grep("MTSKNN",installed.packages()[,1]))==0){
    install.packages("MTSKNN",repos=getOption("repos"),dependencies=T)
  }
  require(MTSKNN)
  arglist <- list(...)
  namesPlot <- names(formals(plot.PMop))
  namesMTSKNN <- names(formals(mtsknn.eq))
  #get the args to plot.PMop and set defaults if missing
  plotArgs <- which(names(arglist) %in% namesPlot)
  argsPlot <- arglist[plotArgs]
  if (!"cex.stat" %in% names(argsPlot)) argsPlot$cex.stat <- 0.8
  if (!"x.stat" %in% names(argsPlot)) argsPlot$x.stat <- 0.5
  #get the args to mtsknn.eq and set defaults if missing
  MTSKNNargs <- which(names(arglist) %in% namesMTSKNN)
  argsMTSKNN <- arglist[MTSKNNargs]
  if (!"k" %in% names(argsMTSKNN)) argsMTSKNN$k <- 3
  if (!"print" %in% names(argsMTSKNN)) argsMTSKNN$print <- FALSE
  #get the others if there and assume that they are PMdata objects for now
  if((length(arglist) - length(c(plotArgs,MTSKNNargs)))>0){
    if(length(c(plotArgs,MTSKNNargs))==0) {argsPM <- 1:length(arglist)} else {argsPM <- (1:length(arglist))[-c(plotArgs,MTSKNNargs)]}
  } else {argsPM <- NULL}
  
  if(length(argsPM)==0) obj <- list(x,y)
  if(length(argsPM)>=1) obj <- c(list(x,y),arglist[argsPM])
  
  
  
  
  objClass <- mapply(class, obj)
  #check for non-Pmetrics data objects and remove them if found
  yesPM <- which(objClass %in% c("NPAG","IT2B"))
  obj <- obj[yesPM]
  objClass <- objClass[yesPM]
  nobj <- length(obj)
  
  #check for zero cycle objects
  cycles <- unlist(sapply(obj,function(x) x$icyctot))
  if(any(cycles==0)) stop(paste("Do not include 0-cycle runs: item(s) ",paste(which(cycles==0),collapse=", "),"\n",sep=""))
  op <- mapply(makeOP, obj)
  if (plot) {
    if (!"resid" %in% names(argsPlot)) {
      if (nobj <= 3) {
        par(mfrow = c(nobj, 2))
      }
      else {
        par(mfrow = c(3, 2))
        devAskNewPage(ask = T)
      }
      for (i in 1:ncol(op)) {
        do.call(plot.PMop, args=c(list(x=op[, i], type="pop", outeq=outeq,                        
                                       main = paste("Model",i, "Population")),argsPlot))
        do.call(plot.PMop, args=c(list(x=op[, i], type="post", outeq=outeq, 
                                       main = paste("Model",i, "Posterior")),argsPlot))
      }
    }
    else {
      devAskNewPage(ask = T)
      for (i in 1:ncol(op)) {
        do.call(plot.PMop,args=c(list(x=op[, i], type="post", outeq=outeq,
                                      main = paste("Model",i)),argsPlot))
      }
    }
    par(mfrow = c(1, 1))
    devAskNewPage(ask = F)
  }
  
  #get the subset of op which is outeq
  opSub <- lapply(op,function(x) x[x$outeq[1]==outeq])
  opSub <- opSub[unlist(lapply(opSub, ncol) !=0)]
  
  #get summary of subset
  sumobj <- mapply(summary.PMop,opSub)
  
  
  Bias <- sapply(sumobj[2,],function(x) ifelse(is.na(x[1]),NA,x$mwpe))
  Imp <- sapply(sumobj[2,],function(x) ifelse(is.na(x[1]),NA,x$bamwspe))
  Percent_RMSE <- sapply(sumobj[2,],function(x) ifelse(is.na(x[1]),NA,x$percent_rmse))
  
  popBias <- Bias[seq(1,2*nobj-1,2)]
  postBias <- Bias[seq(2,2*nobj,2)]
  popImp <- Imp[seq(1,2*nobj-1,2)]
  postImp <- Imp[seq(2,2*nobj,2)]
  popPercent_RMSE <- Percent_RMSE[seq(1,2*nobj-1,2)]
  postPercent_RMSE <- Percent_RMSE[seq(2,2*nobj,2)]
  
  #if all NPAG, calculate nearest neighbors p-value compared to first
  if(all(sapply(obj,function(x) inherits(x,"NPAG")))){
    #get population points
    final <- mapply(makeFinal, obj)
    #find intersecting parameters
    popPointsRef <- final[,1]$popPoints
    namesRef <- names(popPointsRef)
    popPointsOther <- lapply(2:nobj,function(x) final[,x]$popPoints)
    t <- sapply(2:nobj,function(x) {
      thisPopPoints <- popPointsOther[[x-1]]
      namesThis <- names(thisPopPoints)
      intersect <- namesRef[namesRef %in% namesThis]
      if(length(intersect)>0){
        popPoints1 <- popPointsRef[,intersect]
        popPoints2 <- thisPopPoints[,intersect]
        t <- do.call(mtsknn.eq,args=c(list(x=popPoints1,y=popPoints2),argsMTSKNN))$pval
      } else {t <- NA}
      signif(t,3)
    })
    
    t <- c(NA,t)
  } else {t <- NA}
  
  results <- data.frame(type = objClass, 
                        nsub = mapply(function(x) x$nsub, obj), 
                        nvar = mapply(function(x) x$nvar, obj), 
                        par = mapply(function(x) paste(x$par,collapse = " "), obj),
                        converge = mapply(function(x) x$converge==1, obj), 
                        ll = mapply(function(x) -2*x$ilog[length(x$ilog)], obj), 
                        aic = mapply(function(x) tail(x$iic[,1], 1), obj), 
                        bic = mapply(function(x) tail(x$iic[,2], 1), obj), 
                        popBias = popBias,
                        popImp = popImp,
                        popPer_RMSE = popPercent_RMSE,
                        postBias = postBias,
                        postImp = postImp,
                        postPer_RMSE = postPercent_RMSE,
                        pval = t)
  names(results)[6] <- "-2*LL"
  results[,6:14] <- format(results[,6:14],digits=4)
  row.names(results) <- 1:nobj
  results
}
