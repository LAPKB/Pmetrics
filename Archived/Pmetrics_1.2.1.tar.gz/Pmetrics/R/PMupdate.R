#' Download and install Pmetrics updates from LAPK website
#'
#' @title Download and install Pmetrics updates
#' @param test Boolean operator to test downloading.  Default is false.
#' @return The latest system-specific Pmetrics update will be downloaded to a temporary
#' folder and then installed.  You need to restart R (Rstudio) and then reload Pmetrics with
#' the \code{library(Pmetrics)} command to complete the installation.
#' @author Michael Neely

PMupdate <- function(test=F){
  
  currentVersion <- package_version(suppressWarnings(
    tryCatch(scan("http://www.lapk.org/software/Pmetrics/PmetricsVersion.txt",what="character",quiet=T), 
             error = function(e) e <-"0.1")))  
  if(currentVersion=="0.1"){cat("LAPK server not available. Check your internet connection.\n");return(invisible(FALSE))}
  installedVersion <- packageVersion("Pmetrics")
  if(!test & installedVersion >= currentVersion){
    cat("You have the most current version of Pmetrics.\n")
    return(invisible(FALSE))
  } else {
    update <- readline(paste("Version",currentVersion,"is available.  Update? y/n \n"))
    if(tolower(update)=="y"){
      cat("Contacting LAPK server...\n")
      flush.console()
      updateURL <- "http://www.lapk.org/software/Pmetrics/"
      OS <- getOS()
      tempdir <- tempdir()
      dir.create(tempdir,showWarnings=F)
      download <- paste(updateURL,"Pmetrics_",currentVersion,".",c("tgz","zip","tar.gz")[OS],sep="")
      dl <- try(download.file(download,paste(tempdir,"/Pmetrics.",c("tgz","zip","tar.gz")[OS],sep=""),quiet=T),silent=T)
      if(!is.null(attr(dl,"condition"))) stop(attr(dl,"condition"))      
      if(OS==1 | OS==3) system(paste("R CMD INSTALL ",tempdir,"/Pmetrics.",c("tgz","zip","tar.gz")[OS],sep=""))
      if(OS==2) {
        detach("package:Pmetrics")
        shell(paste("R CMD INSTALL ",tempdir,"/Pmetrics.",c("tgz","zip","tar.gz")[OS],sep=""))
      }
      cat("\nRestart R to complete the update.\n")
      flush.console()
      unlink(tempdir,recursive=T)
      
      return(invisible(TRUE))
      
      
    } else {return(invisible(FALSE))}
  }
}
