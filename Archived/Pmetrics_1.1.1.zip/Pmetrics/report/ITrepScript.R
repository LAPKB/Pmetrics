require(Pmetrics)
wd <- commandArgs()[6]
setwd(wd)
ITreport(wd)


