.onLoad <-function (lib, pkg) {
  packageStartupMessage("     Loading library npde, version 2.0, August 2012\n         please direct bugs, questions and feedback to emmanuelle.comets@inserm.fr\n")
#  cat("     Loading library npde, version 1.2, February 15th, 2012\n")
#  cat("         please direct bugs, questions and feedback to emmanuelle.comets@inserm.fr\n")
}
